# Asset Manager

## A asset management tool for analyze stock

