module.exports = {
    static: {
        js: []
    }
};