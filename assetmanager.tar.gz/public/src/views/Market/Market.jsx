import React, { Component } from 'react';
import { Grid, Row, Col, Table } from 'react-bootstrap';

export default class Market extends Component {
    componentDidMount() {
        console.log('something on mount');
    }
    render() {
        

    }
}