exports.index = (req, res) => {
    res.render('index', { title: 'Title', message: 'Hello'});
};

