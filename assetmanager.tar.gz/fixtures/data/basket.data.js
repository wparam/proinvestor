[
    {
        "name": "NASDAQ-100",
        "componentUrl": "https://www.nasdaq.com/quotes/nasdaq-100-stocks.aspx?render=download",
        "componentType": "csv"   
    }
]