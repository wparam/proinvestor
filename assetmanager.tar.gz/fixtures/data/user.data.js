[
    {
        "displayName": "Test User",
        "userName": "test",
        "password":"a",
        "passwordConf": "a",
        "email": "a@a.com"
    }
]