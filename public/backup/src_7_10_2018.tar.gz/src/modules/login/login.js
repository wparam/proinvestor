module.exports = {
    hello: function(){
        console.log('hello');
    }
};